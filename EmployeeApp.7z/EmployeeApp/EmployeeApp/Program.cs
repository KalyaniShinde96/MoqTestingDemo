﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

Console.WriteLine("Enter two numbers\n");
int iNumber1;
int iNumber2;
iNumber1 = int.Parse(Console.ReadLine());
iNumber2 = int.Parse(Console.ReadLine());
HelperClass helper = new HelperClass();
int x = helper.Add(iNumber1, iNumber2);
Console.WriteLine("\nThe sum of " + iNumber1 + " and " + iNumber2 + " is " + x);
Console.ReadKey();


