﻿
public class HelperClass
{
    public HelperClass() { }
    public int Add(int a, int b)
    {
        int x = a + b;
        return x;
    }
    public String CheckPwd(string user)
    {
        if (user == "admin")
        {
            return "Sucessful";
        }
        else
        {
            return "Failed";
        }


    }
    /// <summary>
    /// string assert function used for tessting
    /// </summary>
    /// <returns></returns>
    public string ValidContent_URL()
    {
        //string Test;
        string url = "http://google.com";
        string content = url;
        if (content.Contains("xyz")){
            Console.WriteLine("Expeceted url incorrect");
        }
        else
        {
            Console.WriteLine("Expected url corrrect");
        }
        return content;
    }
    
    void clean()
    {

    }

   
}