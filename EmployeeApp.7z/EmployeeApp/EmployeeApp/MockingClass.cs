﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeApp
{
    public class MockingClass
    {
        private readonly IMockDemo moqDemo1;
        public MockingClass(IMockDemo moqDemo)
        {
            moqDemo1 = moqDemo ?? throw new ArgumentNullException(nameof(moqDemo));
        }

        public void Ping()
         {
            moqDemo1.CheckMoqObj("PING");
         }

     }
     public interface IMockDemo
    {
         bool CheckMoqObj(string command);
     }

      
          
    }
