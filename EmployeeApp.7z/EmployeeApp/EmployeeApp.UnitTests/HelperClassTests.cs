using NUnit.Framework;
using Moq;
using EmployeeApp;

namespace EmployeeApp.UnitTests
{
    using EmployeeApp;
    using System.ComponentModel.DataAnnotations;
    using System.Security.Cryptography;

    [TestFixture]
    public class HelperClassTests
    {
        private HelperClass helperobj;

        [SetUp]
        public void setup() {
            helperobj = new HelperClass();
        }
        [Test]
        public void AddTest()
        {
            var helper = new HelperClass();
            int result = helper.Add(10, 20);
            Assert.That(result, Is.EqualTo(30));
        }
        [Test]
        public void AddTest_For_Negative()
        {
            var helper = new HelperClass();
            int results = helper.Add(-10, 10);
            Assert.That(results, Is.Not.EqualTo(10));
        }

        [Test]
        public void CheckPwd_Valid()
        {
            var helper = new HelperClass();
            var result = helper.CheckPwd("admin");
            Assert.That(result, Is.EqualTo("Sucessful"));
           
        }

        [Test]
        public void CheckPwd_InValid()
        {
            var helper = new HelperClass();
            var result = helper.CheckPwd("test");
            Assert.That(result, Is.Not.EqualTo("Sucessful"));

        }

        [Test]
        public void CheckPwd_Null()
        {
            var helper = new HelperClass();
            var result = helper.CheckPwd(null);
            Assert.That(result, Is.Not.EqualTo("Sucessful"));
        }
        //Test for string Assertion
        [Test]
        

        public void ValidContent_URL_check()
        {
            var helper = new HelperClass();
            string url = "http://google.com";
            string content = helper.ValidContent_URL();
            StringAssert.Contains("http://google.com", content, "Expected not found");
        }
        //Test for moq the object

        [Test]
        public void Ping_Invoke_CheckMoqObj()
        {
            //arrange
            var mock = new Mock<IMockDemo>();
            mock.Setup(p => p.CheckMoqObj(It.IsAny<string>())).Returns(true);
            var sut = new MockingClass(mock.Object);
            //Act
            sut.Ping();
            //Assert
            mock.Verify(p => p.CheckMoqObj("PING"), Times.Once());
        }
        



    }
}